let copyright=new Date();

let update=copyright.getFullYear();

document.querySelector('.copy-title').textContent = "L' Atelier "+ update +" Todos los Derechos Reservados © ";
